import streamlit as st
import pandas as pd
import joblib

# Load trained model
model = joblib.load("insurance_model.pkl")

# Custom CSS for better UI
st.markdown(
    """
    <style>
        body {
            background: linear-gradient(to right, #4facfe, #00f2fe);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
        }
        .main {
            background-color: white;
            padding: 25px;
            border-radius: 20px;
            box-shadow: 0px 10px 40px rgba(0, 0, 0, 0.15);
            width: 65%;
            margin: 30px auto;
            text-align: center;
        }
        .stButton button {
            background: linear-gradient(135deg, #ff512f, #dd2476);
            color: white;
            font-size: 18px;
            font-weight: bold;
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .stButton button:hover {
            background: linear-gradient(135deg, #dd2476, #ff512f);
            transform: scale(1.05);
        }
        .sidebar .sidebar-content {
            background: #f7f7f7;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0px 10px 30px rgba(0, 0, 0, 0.1);
        }
        h1, h2 {
            color: #333;
        }
        h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        h2 {
            color: #4fa3f7;
            font-size: 1.8em;
            margin-bottom: 20px;
        }
        .result {
            margin-top: 30px;
            padding: 20px;
            background-color: #f7f7f7;
            border-radius: 10px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        .result h1 {
            color: #dd2476;
            font-size: 2.5em;
        }
    </style>
    """,
    unsafe_allow_html=True
)

# Streamlit UI
st.markdown("<h1 style='text-align: center;'>💰 Insurance Premium Prediction 💰</h1>", unsafe_allow_html=True)
st.write("Enter your details below to predict your estimated insurance premium.")

# Sidebar for user input
with st.sidebar:
    st.header("🔹 Input Details")
    age = st.number_input("Age", min_value=18, max_value=100, step=1)
    sex = st.selectbox("Sex", ["male", "female"])
    bmi = st.number_input("BMI", min_value=10.0, max_value=50.0, step=0.1)
    children = st.number_input("Children", min_value=0, max_value=10, step=1)
    smoker = st.selectbox("Smoker", ["yes", "no"])
    region = st.selectbox("Region", ["southwest", "southeast", "northwest", "northeast"])

# Predict button & result
if st.button("🚀 Predict Premium"):
    input_data = pd.DataFrame([[age, sex, bmi, children, smoker, region]],
                              columns=["age", "sex", "bmi", "children", "smoker", "region"])
    
    # Prediction
    prediction = model.predict(input_data)[0]
    
    # Styled result
    st.markdown(
        f"""
        <div class="result">
            <h2>📊 Estimated Insurance Premium</h2>
            <h1>${prediction:.2f}</h1>
            <p style="color: #888;">Thank you for using our prediction tool! 📈</p>
        </div>
        """,
        unsafe_allow_html=True
    )
